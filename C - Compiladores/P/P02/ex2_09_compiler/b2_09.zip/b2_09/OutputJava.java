
public class OutputJava {
   public static void main(String[] args) {
      Fraction x = new Fraction(3,4);
      System.out.println(new Fraction(1,4).toString());
      System.out.println(new Fraction(3).toString());
      System.out.println(x.toString());
   }
}
