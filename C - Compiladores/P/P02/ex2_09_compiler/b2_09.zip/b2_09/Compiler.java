import java.io.File;
import org.stringtemplate.v4.*;

@SuppressWarnings("CheckReturnValue")
public class Compiler extends CalFracBaseVisitor<ST> {

   private STGroup stg;

   public boolean validTarget(String target) {
      File f = new File(target+".stg");
      return ("java".equalsIgnoreCase(target) || "c".equalsIgnoreCase(target)) &&
             f.exists() && f.isFile() && f.canRead();
   }

   public void setTarget(String target) {
      assert validTarget(target);
      stg = new STGroupFile(target+".stg");
   }
   
   @Override public ST visitProgram(CalFracParser.ProgramContext ctx) {
      ST res = stg.getInstanceOf("module");
      String[] stat= new String[ctx.stat().size()];
      for(int i=0;i<ctx.stat().size();i++){
         stat[i]=visit(ctx.stat(i)).render();
         System.out.println(stat[i]);
      }
      res.add("stat", stat);
      return res;
   }
   @Override public ST visitExprINT(CalFracParser.ExprINTContext ctx)
   {
      ST res = new ST("new Fraction(<value>)");
      res.add("value", ctx.INT().getText());
      return res;
   }
   @Override public ST visitStatAssign(CalFracParser.StatAssignContext ctx) {
      return visit(ctx.assign());
   }

   @Override public ST visitStatPrint(CalFracParser.StatPrintContext ctx) {
      return visit(ctx.print());
   }

   @Override public ST visitPrint(CalFracParser.PrintContext ctx) {
      
      ST res = new ST("System.out.println(<expr>.toString());");
      res.add("expr", visit(ctx.expr()).render());
      return res;
   }

   @Override public ST visitAssign(CalFracParser.AssignContext ctx) {
      ST res = new ST("Fraction <id> = <expr>;");
      res.add("id", ctx.ID().getText());
      res.add("expr", visit(ctx.expr()).render());
      return res;
   }

   @Override public ST visitExprMULDIV(CalFracParser.ExprMULDIVContext ctx) {
      if(ctx.op.getText().equals("*")){
         ST res = new ST("<expr1>.mulTo(<expr2>)");
         res.add("expr1", visit(ctx.expr(0)).render());
         res.add("expr2", visit(ctx.expr(1)).render());
         return res;
      }
      else{
         ST res = new ST("<expr1>.divTo(<expr2>)");
         res.add("expr1", visit(ctx.expr(0)).render());
         res.add("expr2", visit(ctx.expr(1)).render());
         return res;
      }


   }

   @Override public ST visitExprUMINUS(CalFracParser.ExprUMINUSContext ctx) {
      ST res = new ST("<expr>.setNumerator(" +ctx.op.getText()+ "<expr>.getNumerator())"); 
      res.add("expr", visit(ctx.expr()).render());
      return res;
   }

   @Override public ST visitExprADDSUB(CalFracParser.ExprADDSUBContext ctx) {
      if(ctx.op.getText().equals("+")){
         ST res = new ST("<expr1>.addTo(<expr2>)");
         res.add("expr1", visit(ctx.expr(0)).render());
         res.add("expr2", visit(ctx.expr(1)).render());
         return res;
      }
      else{
         ST res = new ST("<expr1>.subTo(<expr2>)");
         res.add("expr1", visit(ctx.expr(0)).render());
         res.add("expr2", visit(ctx.expr(1)).render());
         return res;
      }

   }

   @Override public ST visitExprPARENS(CalFracParser.ExprPARENSContext ctx) {
      
      return visit(ctx.expr());
   
   }

   @Override public ST visitExprReduce(CalFracParser.ExprReduceContext ctx) {
      ST res = new ST("<expr>.reduce()");
      res.add("expr", visit(ctx.expr()).render());
      return res;
   }

   @Override public ST visitExprID(CalFracParser.ExprIDContext ctx) {
      ST res = new ST("<ID>");
      res.add("ID", ctx.ID().getText());
      return res;
   }

   @Override public ST visitExprFraction(CalFracParser.ExprFractionContext ctx) {
      ST res = new ST("new Fraction(<num>,<denom>)");
      res.add("num", ctx.INT(0).getText());
      res.add("denom", ctx.INT(1).getText());
      return res;
   }
}
