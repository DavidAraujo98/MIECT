import java.util.*;

@SuppressWarnings("CheckReturnValue")
public class Execute extends CalFracBaseVisitor<Fraction> {
   
   HashMap<String,Fraction> map = new HashMap<>();

   @Override public Fraction visitProgram(CalFracParser.ProgramContext ctx) {
      return visitChildren(ctx);
   }

   @Override public Fraction visitStatAssign(CalFracParser.StatAssignContext ctx) {
      return visitChildren(ctx.assign());
   }

   @Override public Fraction visitStatPrint(CalFracParser.StatPrintContext ctx) {
      return visitChildren(ctx.print());
   }

   @Override public Fraction visitAssign(CalFracParser.AssignContext ctx) {
      String key = ctx.ID().getText();
      Fraction value = visit(ctx.expr());
      map.put(key,value);
      return value;
   }

   @Override public Fraction visitPrint(CalFracParser.PrintContext ctx) {
      Fraction f = visit(ctx.expr());
      System.out.println(f);
      return null;
   }

   @Override public Fraction visitExprMULDIV(CalFracParser.ExprMULDIVContext ctx) {
      if (ctx.op.getText().equals("*"))
         return visit(ctx.expr(0)).mulTo(visit(ctx.expr(1)));
      else if (ctx.op.getText().equals(":"))
         return visit(ctx.expr(0)).divTo(visit(ctx.expr(1)));
   
     return null;
   }

   @Override public Fraction visitExprUMINUS(CalFracParser.ExprUMINUSContext ctx) {
      if (ctx.op.getText().equals("-"))
      return (new Fraction()).subTo(visit(ctx.expr()));
      
      else if (ctx.op.getText().equals("+"))
         return visit(ctx.expr());
    
      return null;
   }
   

   @Override public Fraction visitExprADDSUB(CalFracParser.ExprADDSUBContext ctx) {
      if (ctx.op.getText().equals("+"))
         return visit(ctx.expr(0)).addTo(visit(ctx.expr(1)));
      else if (ctx.op.getText().equals("-"))
         return visit(ctx.expr(0)).subTo(visit(ctx.expr(1)));

      return null;
   }

   @Override public Fraction visitExprPARENS(CalFracParser.ExprPARENSContext ctx) {
      return visit(ctx.expr());
   }

   @Override public Fraction visitExprReduce(CalFracParser.ExprReduceContext ctx) {
      Fraction fraction = visit(ctx.expr());
      fraction.reduce();
      return fraction;
   }

   @Override public Fraction visitExprID(CalFracParser.ExprIDContext ctx) {
      return map.get(ctx.ID().getText());
   }

   @Override public Fraction visitExprFraction(CalFracParser.ExprFractionContext ctx) {
      return new Fraction(Integer.parseInt(ctx.INT(0).getText()), Integer.parseInt(ctx.INT(1).getText()));
    }
}

   

